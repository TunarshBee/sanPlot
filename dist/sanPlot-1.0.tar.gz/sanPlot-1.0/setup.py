from setuptools import setup

setup(
    name='sanPlot',
    version='1.0',
    description='A data visualization package',
    author='Your Name',
    packages=['sanPlot'],
    install_requires=['plotly', 'matplotlib','netgraph','numpy','circlify']
)
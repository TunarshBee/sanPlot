# my_network_package/network_visualizer.py

import matplotlib.pyplot as plt
import networkx as nx
from netgraph import Graph

class NetworkVisualizer:
    def __init__(self):
        self.graph = nx.Graph()

    def add_node(self, node):
        self.graph.add_node(node)

    def add_edge(self, node1, node2):
        self.graph.add_edge(node1, node2)

    def plot_network(self):
        pos = nx.spring_layout(self.graph)
        netgraph = Graph(layout="spring", node_size=20)
        netgraph.add_nodes_from(self.graph.nodes)
        netgraph.add_edges_from(self.graph.edges)
        netgraph.draw()
        plt.show()
